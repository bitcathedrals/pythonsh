# pythonsh configuration file
VERSION=0.16.3

PACKAGES=pyutils
SOURCE=.

BUILD_NAME=pythonsh

DOCKER_VERSION="6"
DOCKER_USER="codermattie"

VIRTUAL_PREFIX='pythonsh'
PYTHON_VERSION='3.11'
