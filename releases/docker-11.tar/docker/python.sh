# pythonsh configuration file
VERSION=1.1.0

PACKAGES=pyutils
SOURCE=.

BUILD_NAME=pythonsh

DOCKER_VERSION="11"
DOCKER_USER="codermattie"

VIRTUAL_PREFIX='pythonsh'
PYTHON_VERSION='3.12'
