# pythonsh configuration file
VERSION=0.16.1

PACKAGES=pyutils
SOURCE=.

BUILD_NAME=pythonsh

DOCKER_VERSION="4"
DOCKER_USER="codermattie"

VIRTUAL_PREFIX='pythonsh'
PYTHON_VERSION='3.11'
